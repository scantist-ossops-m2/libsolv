extern int susetags_load_ext(Repo *repo, Repodata *data);
extern int susetags_load(struct repoinfo *cinfo, Pool **sigpoolp);
