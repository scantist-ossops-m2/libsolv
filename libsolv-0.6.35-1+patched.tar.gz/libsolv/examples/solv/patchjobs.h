extern void add_patchjobs(Pool *pool, Queue *job);

