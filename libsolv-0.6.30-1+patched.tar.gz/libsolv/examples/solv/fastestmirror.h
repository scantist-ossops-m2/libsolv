extern void findfastest(char **urls, int nurls);

