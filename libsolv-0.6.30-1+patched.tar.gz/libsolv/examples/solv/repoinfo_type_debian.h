extern int debian_load(struct repoinfo *cinfo, Pool **sigpoolp);

