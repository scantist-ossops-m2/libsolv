int  read_installed_debian(struct repoinfo *cinfo);
void commit_transactionelement_debian(Pool *pool, Id type, Id p, FILE *fp);
